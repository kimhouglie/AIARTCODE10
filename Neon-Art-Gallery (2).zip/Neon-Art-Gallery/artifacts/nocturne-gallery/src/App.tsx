import { useEffect, useState } from 'react';
import { Headphones, Pause, Play, Volume2, VolumeX, AudioLines } from 'lucide-react';
import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

type Artwork = {
  title: string;
  subtitle: string;
  description: string;
  date: string;
  medium: string;
  duration: string;
  edition: string;
  curator: string;
  narration: string;
};

const queryClient = new QueryClient();
const fieldNames: Record<string, keyof Omit<Artwork, 'narration'>> = {
  TITLE: 'title',
  SUBTITLE: 'subtitle',
  DESCRIPTION: 'description',
  DATE: 'date',
  MEDIUM: 'medium',
  DURATION: 'duration',
  EDITION: 'edition',
  CURATOR: 'curator',
};

function parseArtwork(text: string): Artwork {
  const [metadata, ...narrationParts] = text.split(/^NARRATION=\s*$/m);
  const fields: Partial<Artwork> = {};
  metadata.split(/\r?\n/).forEach((line) => {
    const splitAt = line.indexOf('=');
    if (splitAt < 0) return;
    const key = line.slice(0, splitAt).trim();
    const field = fieldNames[key];
    if (field) fields[field] = line.slice(splitAt + 1).trim();
  });
  const narration = narrationParts.join('\n').trim();
  const required = ['title', 'subtitle', 'description', 'date', 'medium', 'duration', 'edition', 'curator'] as const;
  if (required.some((key) => !fields[key]) || !narration) throw new Error('전시 텍스트 형식을 읽을 수 없습니다.');
  return { ...fields, narration } as Artwork;
}

function Home() {
  const [artwork, setArtwork] = useState<Artwork | null>(null);
  const [loadingError, setLoadingError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [audioOn, setAudioOn] = useState(false);
  const [volume, setVolume] = useState(34);
  const [narrating, setNarrating] = useState(false);
  const [speechUnsupported, setSpeechUnsupported] = useState(false);
  const [speechError, setSpeechError] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      setLoading(true);
      setLoadingError(false);
      try {
        const response = await fetch(`${import.meta.env.BASE_URL}artwork.txt`);
        if (!response.ok) throw new Error('텍스트 파일을 불러오지 못했습니다.');
        const parsed = parseArtwork(await response.text());
        if (alive) setArtwork(parsed);
      } catch {
        if (alive) setLoadingError(true);
      } finally {
        if (alive) setLoading(false);
      }
    };
    void load();
    return () => {
      alive = false;
      window.speechSynthesis?.cancel();
    };
  }, []);

  useEffect(() => {
    setSpeechUnsupported(!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window));
  }, []);

  const toggleAudio = async () => {
    try {
      const win = window as typeof window & { nocturneAudio?: { context: AudioContext; master: GainNode } };
      let audio = win.nocturneAudio;
      if (!audio) {
        const context = new AudioContext();
        const master = context.createGain();
        master.gain.value = 0;
        master.connect(context.destination);
        [73.42, 110, 146.83].forEach((frequency, index) => {
          const oscillator = context.createOscillator();
          const tone = context.createGain();
          oscillator.type = index === 1 ? 'triangle' : 'sine';
          oscillator.frequency.value = frequency;
          tone.gain.value = index === 0 ? 0.34 : 0.12;
          oscillator.connect(tone);
          tone.connect(master);
          oscillator.start();
        });
        audio = { context, master };
        win.nocturneAudio = audio;
      }
      await audio.context.resume();
      const next = !audioOn;
      audio.master.gain.setTargetAtTime(next ? (volume / 100) * 0.045 : 0, audio.context.currentTime, 0.7);
      setAudioOn(next);
    } catch {
      setAudioOn(false);
    }
  };

  const changeVolume = (next: number) => {
    setVolume(next);
    const audio = (window as typeof window & { nocturneAudio?: { context: AudioContext; master: GainNode } }).nocturneAudio;
    if (audio && audioOn) audio.master.gain.setTargetAtTime((next / 100) * 0.045, audio.context.currentTime, 0.15);
  };

  const toggleNarration = () => {
    if (!artwork || speechUnsupported) return;
    if (narrating) {
      window.speechSynthesis.cancel();
      setNarrating(false);
      return;
    }
    window.speechSynthesis.cancel();
    setSpeechError(false);
    const utterance = new SpeechSynthesisUtterance(artwork.narration);
    utterance.lang = 'ko-KR';
    utterance.rate = 0.88;
    utterance.pitch = 0.92;
    utterance.onstart = () => setNarrating(true);
    utterance.onend = () => setNarrating(false);
    utterance.onerror = () => {
      setNarrating(false);
      setSpeechError(true);
    };
    window.speechSynthesis.speak(utterance);
  };

  if (loading) {
    return <main className="gallery-shell load-state" aria-label="전시 준비 중"><div className="skeleton" role="status" aria-label="전시 정보를 불러오는 중" data-testid="status-loading" /></main>;
  }
  if (loadingError || !artwork) {
    return <main className="gallery-shell load-state"><div><p data-testid="status-load-error">전시 정보를 불러오지 못했습니다.</p><button type="button" onClick={() => window.location.reload()} data-testid="button-retry">다시 불러오기</button></div></main>;
  }

  return (
    <main className="gallery-shell">
      <header className="masthead">
        <a href={import.meta.env.BASE_URL} className="wordmark" aria-label="Nocturne 전시 홈" data-testid="link-nocturne-home"><strong>Nocturne</strong><span>one work · one visitor</span></a>
        <div className="edition"><span data-testid="text-edition">{artwork.edition}</span></div>
      </header>
      <section className="exhibition-layout" aria-label="단일 작품 전시">
        <div className="intro-line">
          <span>야간 관람 · NIGHT SESSION</span>
          <span className="online"><i aria-hidden="true" /> 혼자만의 전시</span>
        </div>
        <div className="stage">
          <div className="art-frame">
            <span className="frame-index" aria-hidden="true">Nº 001 / MOVING IMAGE</span>
            <iframe className="art-iframe" src={`${import.meta.env.BASE_URL}art1.html`} title={artwork.title} allow="fullscreen" data-testid="artwork-frame" />
            <span className="frame-caption" aria-hidden="true">MOVE TO ALTER THE FIELD</span>
          </div>
        </div>
        <section className="work-details" aria-label="작품 정보">
          <div className="work-heading">
            <div className="eyebrow" data-testid="text-subtitle">{artwork.subtitle}</div>
            <h1 data-testid="text-artwork-title">{artwork.title}</h1>
            <p className="summary" data-testid="text-artwork-description">{artwork.description}</p>
          </div>
          <dl className="meta-grid" data-testid="artwork-metadata">
            <div className="meta-item"><dt>제작 연도</dt><dd data-testid="text-artwork-date">{artwork.date}</dd></div>
            <div className="meta-item"><dt>매체</dt><dd data-testid="text-artwork-medium">{artwork.medium}</dd></div>
            <div className="meta-item"><dt>감상 시간</dt><dd data-testid="text-artwork-duration">{artwork.duration}</dd></div>
            <div className="meta-item"><dt>전시 번호</dt><dd data-testid="text-artwork-edition">{artwork.edition}</dd></div>
          </dl>
          <div className="curator">
            <div className="section-label"><AudioLines size={12} aria-hidden="true" /> 큐레이터의 목소리</div>
            <blockquote aria-label="전체 큐레이터 작품 설명" tabIndex={0} data-testid="text-curator-narration">{artwork.narration}</blockquote>
            <cite data-testid="text-curator-name">{artwork.curator}</cite>
            <div className="control-row" style={{ marginTop: 15 }}>
              <button type="button" className="control-button" onClick={toggleNarration} disabled={speechUnsupported} aria-pressed={narrating} data-testid="button-narration">
                {narrating ? <Pause aria-hidden="true" /> : <Headphones aria-hidden="true" />}
                {narrating ? '낭독 멈춤' : '낭독 듣기'}
              </button>
              {speechError && <span role="status" data-testid="status-speech-error" style={{ color: '#d7a5a5', fontSize: 10 }}>음성 재생을 시작할 수 없습니다.</span>}
              {speechUnsupported && <span role="status" data-testid="status-speech-unsupported" style={{ color: '#aaa3ac', fontSize: 10 }}>이 브라우저는 음성 낭독을 지원하지 않습니다.</span>}
            </div>
          </div>
        </section>
        <div className="footerline">
          <div className="control-row">
            <button type="button" className="control-button" onClick={toggleAudio} aria-pressed={audioOn} data-testid="button-soundtrack">
              {audioOn ? <Pause aria-hidden="true" /> : <Play aria-hidden="true" />}
              {audioOn ? '사운드 끄기' : '사운드 듣기'}
            </button>
            <label className="volume-wrap" aria-label="사운드 음량">
              {volume === 0 ? <VolumeX aria-hidden="true" /> : <Volume2 aria-hidden="true" />}
              <input type="range" min="0" max="100" value={volume} onChange={(event) => changeVolume(Number(event.target.value))} aria-label="사운드 음량" data-testid="input-volume" />
            </label>
          </div>
          <span data-testid="text-audio-disclosure">소리는 이 기기에서만 생성됩니다</span>
        </div>
      </section>
    </main>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
