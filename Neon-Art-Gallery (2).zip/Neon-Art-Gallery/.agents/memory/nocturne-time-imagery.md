---
name: Nocturne time imagery
description: Semantic color roles and intended trail behavior for the moving artwork.
---

In Nocturne's artwork, white represents the present and red represents the future. Trail echoes should be position snapshots that stay fixed and fade, not a continuously moving smear. Faster movement should leave fewer echoes.

**Why:** The user explicitly defined these color meanings and the speed-dependent afterimage behavior.

**How to apply:** Preserve these meanings and behaviors in future changes to the artwork animation.
